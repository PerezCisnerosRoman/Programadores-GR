package com.example.programagr.ejercicio

import android.content.Intent
import android.os.Bundle
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.programagr.R
import com.example.programagr.kotlin.MainActivity
import com.example.programagr.netbeans.netbeanskt

class Main_home : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_main_home_ejercicios)


        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        val recycler = findViewById<RecyclerView>(R.id.recyclerEjercicios)


        val ejercicioHomeHomes = listOf(
            Ejercicio_home(
                "Android Studio Kotlin",
                "Escribe un programa que muestre tu nombre y edad",
                        R.drawable.kotlin

            ),
            Ejercicio_home(
                "Apache Netbeans",
                "Crea variables de tipo String, Int, Double, Boolean",
                R.drawable.java
            ),
            Ejercicio_home(
                "My SQL",
                "Crea una función que reciba 2 números y regrese su multiplicación",
                R.drawable.mysql
            )
        )


        recycler.layoutManager = GridLayoutManager(this, 1)

// Pass the lambda function to handle the click
        recycler.adapter = EjercicioAdapter(ejercicioHomeHomes) { ejercicioClicked ->
            // Create the Intent to switch activities
            val intent = Intent(this, ejer1_home::class.java)

            // Optional: Pass data to the new activity
// ... inside the adapter lambda ...
            intent.putExtra("TITULO", ejercicioClicked.titulo)
            intent.putExtra("DESCRIPCION", ejercicioClicked.descripcion)

// Passing the Integer Resource ID (e.g., R.drawable.cotli)
            intent.putExtra("IMAGEN", ejercicioClicked.imagen)

            if (ejercicioClicked.titulo == "Android Studio Kotlin") {
                val intent = Intent(this, Main_home::class.java)
                startActivity(intent)
            }
            if(ejercicioClicked.titulo == "Apache Netbeans") {
                val intent = Intent(this, netbeanskt::class.java)
                startActivity(intent)
            }
            if(ejercicioClicked.titulo == "My SQL") {
                val intent = Intent(this, netbeanskt::class.java)
                startActivity(intent)
            }
        }
    }
}

// New Data Class
data class Ejercicio_home(val titulo: String, val descripcion: String, val imagen: Int)
