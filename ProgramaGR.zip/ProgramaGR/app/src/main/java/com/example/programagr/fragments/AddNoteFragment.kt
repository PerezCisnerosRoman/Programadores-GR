package com.example.programagr.fragments

import android.os.Bundle
import android.view.*
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.MenuHost
import androidx.core.view.MenuProvider
import androidx.fragment.app.Fragment
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.ViewModelProvider
import androidx.navigation.findNavController
import com.example.programagr.R
import com.example.programagr.database.NoteDatabase
import com.example.programagr.databinding.FragmentAddNoteBinding
import com.example.programagr.model.Note
import com.example.programagr.repository.NoteRepository
import com.example.programagr.viewmodel.NoteViewModel
import com.example.programagr.viewmodel.NoteViewModelFactory

class AddNoteFragment : Fragment(R.layout.fragment_add_note), MenuProvider {

    private var _binding: FragmentAddNoteBinding? = null
    private val binding get() = _binding!!

    private lateinit var notesViewModel: NoteViewModel

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?,
    ): View {
        _binding = FragmentAddNoteBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        // ===== CONFIGURACIÓN DE LA TOOLBAR Y EL MENÚ =====
        val toolbar = binding.addNoteToolbar
        (requireActivity() as AppCompatActivity).setSupportActionBar(toolbar)

        val menuHost: MenuHost = requireActivity()
        menuHost.addMenuProvider(this, viewLifecycleOwner, Lifecycle.State.RESUMED)
        // ===== FIN DE LA CONFIGURACIÓN DE LA TOOLBAR =====

        // Inicialización del ViewModel
        val noteDatabase = NoteDatabase(requireContext())
        val noteRepository = NoteRepository(noteDatabase)
        val viewModelProviderFactory = NoteViewModelFactory(requireActivity().application, noteRepository)

        notesViewModel = ViewModelProvider(
            requireActivity(), viewModelProviderFactory)[NoteViewModel::class.java]
    }

    private fun saveNote() {
        val noteTitle = binding.addNoteTitle.text.toString().trim()
        val noteDesc = binding.addNoteDesc.text.toString().trim()

        if (noteTitle.isNotEmpty()) {
            val note = Note(0, noteTitle, noteDesc)
            notesViewModel.addNote(note) // Usando la función correcta 'addNote'

            Toast.makeText(requireContext(), "Nota Guardada", Toast.LENGTH_SHORT).show()
            view?.findNavController()?.popBackStack()
        } else {
            Toast.makeText(requireContext(), "Por favor, ingrese un título para la nota", Toast.LENGTH_SHORT).show()
        }
    }

    override fun onCreateMenu(menu: Menu, menuInflater: MenuInflater) {
        menu.clear()
        menuInflater.inflate(R.menu.menu_add_note, menu)
    }

    override fun onMenuItemSelected(menuItem: MenuItem): Boolean {
        return when (menuItem.itemId) {
            R.id.saveMenu -> {
                saveNote()
                true
            }
            else -> false
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
