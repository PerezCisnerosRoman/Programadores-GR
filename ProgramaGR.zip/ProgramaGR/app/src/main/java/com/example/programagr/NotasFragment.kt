package com.example.programagr // Asegúrate de que el paquete sea el correcto

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.lifecycle.ViewModelProvider
import com.example.programagr.database.NoteDatabase
import com.example.programagr.repository.NoteRepository
import com.example.programagr.viewmodel.NoteViewModel
import com.example.programagr.viewmodel.NoteViewModelFactory

class NotasFragment : Fragment() { // <-- Hereda de Fragment

    lateinit var noteViewModel: NoteViewModel

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        val view = inflater.inflate(R.layout.fragment_notas, container, false)
        return view
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        setupViewModel()
    }

    // Código corregido para funcionar dentro de un Fragment

    private fun setupViewModel() {
        // ESTA ES LA FORMA CORRECTA PARA *TU* REPOSITORIO
        // Crea una instancia de la BD y se la pasa directamente al Repositorio.
        val noteRepository = NoteRepository(NoteDatabase(requireContext()))

        // El resto del código está bien.
        val application = requireActivity().application
        val viewModelProviderFactory = NoteViewModelFactory(application, noteRepository)

        noteViewModel = ViewModelProvider(this, viewModelProviderFactory)[NoteViewModel::class.java]
    }}