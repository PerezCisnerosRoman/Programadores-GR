package com.example.programagr.fragments

import android.os.Bundle
import android.view.LayoutInflater
import android.view.Menu
import android.view.MenuInflater
import android.view.MenuItem
import android.view.View
import android.view.ViewGroup
import androidx.appcompat.widget.SearchView
import androidx.core.view.MenuHost
import androidx.core.view.MenuProvider
import androidx.fragment.app.Fragment
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.ViewModelProvider
import androidx.navigation.findNavController
import androidx.recyclerview.widget.StaggeredGridLayoutManager
import com.example.programagr.R
import com.example.programagr.adapter.NoteAdapter
import com.example.programagr.database.NoteDatabase
import com.example.programagr.databinding.FragmentHome3Binding
import com.example.programagr.model.Note
import com.example.programagr.repository.NoteRepository
import com.example.programagr.viewmodel.NoteViewModel
import com.example.programagr.viewmodel.NoteViewModelFactory

class HomeFragment2 : Fragment(R.layout.fragment_home3), SearchView.OnQueryTextListener, MenuProvider {

    private var _binding: FragmentHome3Binding? = null
    // Esta propiedad no nula solo es válida entre onCreateView y onDestroyView.
    private val binding get() = _binding!!

    private lateinit var notesViewModel: NoteViewModel
    private lateinit var noteAdapter: NoteAdapter

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        // Inflate the layout for this fragment
        _binding = FragmentHome3Binding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        // --- 1. INICIALIZACIÓN CORRECTA DEL VIEWMODEL ---
        // Se obtiene el ViewModel compartido asociado a la Activity.
        val noteDatabase = NoteDatabase(requireContext())
        val noteRepository = NoteRepository(noteDatabase)
        val viewModelProviderFactory = NoteViewModelFactory(requireActivity().application, noteRepository)

        // LA CLAVE: Se usa 'requireActivity()' como dueño del ViewModel para compartirlo.
        notesViewModel = ViewModelProvider(requireActivity(), viewModelProviderFactory)[NoteViewModel::class.java]

        // --- FIN DE LA CORRECCIÓN ---

        // Configuración del menú
        val menuHost: MenuHost = requireActivity()
        menuHost.addMenuProvider(this, viewLifecycleOwner, Lifecycle.State.RESUMED)

        setupHomeRecyclerView()

        binding.addNoteFab.setOnClickListener {
            it.findNavController().navigate(R.id.action_homeFragment2_to_addNoteFragment)
        }
    }

    private fun updateUI(note: List<Note>?) {
        if (note != null && note.isNotEmpty()) {
            binding.emptyNotesImage.visibility = View.GONE
            binding.homeRecyclerView.visibility = View.VISIBLE
        } else {
            binding.emptyNotesImage.visibility = View.VISIBLE
            binding.homeRecyclerView.visibility = View.GONE
        }
    }

    private fun setupHomeRecyclerView() {
        noteAdapter = NoteAdapter()
        binding.homeRecyclerView.apply {
            layoutManager = StaggeredGridLayoutManager(2, StaggeredGridLayoutManager.VERTICAL)
            setHasFixedSize(true)
            adapter = noteAdapter
        }

        // --- 2. OBSERVACIÓN SEGURA DEL VIEWMODEL ---
        // No es necesario 'activity?.let', ya que estamos dentro del ciclo de vida del fragmento.
        notesViewModel.getAllNotes().observe(viewLifecycleOwner) { note ->
            noteAdapter.differ.submitList(note)
            updateUI(note)
        }
    }

    private fun searchNote(query: String?) {
        val searchQuery = "%$query%" // <- 3. MEJORA EN LA BÚSQUEDA
        notesViewModel.searchNote(searchQuery).observe(viewLifecycleOwner) { list -> // Se usa viewLifecycleOwner
            noteAdapter.differ.submitList(list)
        }
    }

    override fun onQueryTextSubmit(query: String?): Boolean {
        // Normalmente no se usa para búsquedas en tiempo real.
        return false
    }

    override fun onQueryTextChange(newText: String?): Boolean {
        if (newText != null) {
            searchNote(newText)
        }
        return true
    }

    override fun onCreateMenu(menu: Menu, menuInflater: MenuInflater) {
        menu.clear()
        menuInflater.inflate(R.menu.home_menu, menu)

        val menuSearch = menu.findItem(R.id.searchMenu).actionView as? SearchView // Uso de cast seguro
        menuSearch?.isSubmitButtonEnabled = false
        menuSearch?.setOnQueryTextListener(this)
    }

    override fun onMenuItemSelected(menuItem: MenuItem): Boolean {
        // Devolver false indica que no has manejado el evento, permitiendo que otros lo hagan.
        return false
    }

    override fun onDestroyView() {
        super.onDestroyView()
        // Limpiar la referencia al binding para evitar fugas de memoria.
        _binding = null
    }
}
