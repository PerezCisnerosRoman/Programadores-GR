package com.example.programagr.viewmodel

import android.app.Application
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import com.example.programagr.repository.NoteRepository

class NoteViewModelFactory(
    private val app: Application,
    private val noteRepository: NoteRepository
) : ViewModelProvider.Factory {

    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        // --- ESTA ES LA CORRECCIÓN CRUCIAL ---
        // 1. Comprueba si la clase que se pide crear (`modelClass`)
        //    es la misma que `NoteViewModel` o una subclase de ella.
        if (modelClass.isAssignableFrom(NoteViewModel::class.java)) {

            // 2. Si lo es, crea y devuelve una instancia de NoteViewModel.
            //    El @Suppress y el 'as T' aquí son seguros porque ya hemos comprobado el tipo.
            @Suppress("UNCHECKED_CAST")
            return NoteViewModel(app, noteRepository) as T
        }

        // 3. Si se pide crear cualquier otra clase de ViewModel,
        //    lanza una excepción. Esto es importante para detectar errores.
        throw IllegalArgumentException("Unknown ViewModel class")
    }
}
