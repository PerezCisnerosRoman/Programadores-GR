package com.example.programagr // Asegúrate de que el paquete sea el correcto

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment

class AcercaDeFragment : Fragment() { // <-- Hereda de Fragment

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Infla (crea) la vista para este fragmento desde un archivo XML.
        // Necesitas crear el archivo 'fragment_home.xml' en la carpeta 'res/layout'.
        return inflater.inflate(R.layout.fragment_acerca_de, container, false)
    }
}
