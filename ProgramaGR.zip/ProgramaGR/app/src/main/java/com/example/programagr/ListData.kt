package com.example.programagr

class ListData (
    var name: String,
    var time: String,
)