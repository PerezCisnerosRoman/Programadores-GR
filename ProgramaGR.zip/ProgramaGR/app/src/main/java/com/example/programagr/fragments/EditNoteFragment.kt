package com.example.programagr.fragments

import android.os.Bundle
import android.view.*
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.core.view.MenuHost
import androidx.core.view.MenuProvider
import androidx.fragment.app.Fragment
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.ViewModelProvider
import androidx.navigation.findNavController
import androidx.navigation.fragment.navArgs
import com.example.programagr.R
import com.example.programagr.database.NoteDatabase
import com.example.programagr.databinding.FragmentEditNoteBinding
import com.example.programagr.model.Note
import com.example.programagr.repository.NoteRepository
import com.example.programagr.viewmodel.NoteViewModel
import com.example.programagr.viewmodel.NoteViewModelFactory

class EditNoteFragment : Fragment(R.layout.fragment_edit_note), MenuProvider {

    private var _binding: FragmentEditNoteBinding? = null
    private val binding get() = _binding!!

    private lateinit var notesViewModel: NoteViewModel
    private lateinit var currentNote: Note

    private val args: EditNoteFragmentArgs by navArgs()

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?,
    ): View {
        _binding = FragmentEditNoteBinding.inflate(inflater, container, false)
        return binding.root
    }
// En EditNoteFragment.kt

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        // Tu código original, intacto
        val menuHost: MenuHost = requireActivity()
        menuHost.addMenuProvider(this, viewLifecycleOwner, Lifecycle.State.RESUMED)

        // Tu código original, intacto
        val noteRepository = NoteRepository(NoteDatabase(requireContext()))
        val viewModelProviderFactory = NoteViewModelFactory(requireActivity().application, noteRepository)
        notesViewModel = ViewModelProvider(this, viewModelProviderFactory)[NoteViewModel::class.java]

        // Tu código original, intacto
        currentNote = args.note!!
        binding.editNoteTitle.setText(currentNote.noteTitle)
        binding.editNoteDesc.setText(currentNote.noteDesc)

        // =============================================================
        // ===== ¡AÑADE ESTA ÚNICA LÍNEA PARA QUE EL BOTÓN SIRVA! =====
        binding.editNoteFab.setOnClickListener { updateNoteInDb() }
        // =============================================================
    }


    private fun updateNoteInDb() {
        val noteTitle = binding.editNoteTitle.text.toString().trim()
        val noteDesc = binding.editNoteDesc.text.toString().trim()

        if (noteTitle.isNotEmpty()) {
            val note = Note(currentNote.id, noteTitle, noteDesc)
            notesViewModel.updateNote(note)
            Toast.makeText(requireContext(), "Nota Actualizada", Toast.LENGTH_SHORT).show()
            view?.findNavController()?.popBackStack()
        } else {
            Toast.makeText(requireContext(), "Por favor, ingrese un título", Toast.LENGTH_SHORT).show()
        }
    }

    private fun deleteNote() {
        AlertDialog.Builder(requireActivity()).apply {
            setTitle("Eliminar Nota")
            setMessage("¿Estás seguro de que quieres eliminar esta nota?")
            setPositiveButton("Eliminar") { _, _ ->
                notesViewModel.deleteNote(currentNote)
                Toast.makeText(requireContext(), "Nota Eliminada", Toast.LENGTH_SHORT).show()
                view?.findNavController()?.popBackStack()
            }
            setNegativeButton("Cancelar", null)
        }.create().show()
    }

    override fun onCreateMenu(menu: Menu, menuInflater: MenuInflater) {
        menu.clear()
        // Infla el nuevo menú que contiene los botones de guardar y eliminar
        menuInflater.inflate(R.menu.menu_edit_note, menu)
    }

    override fun onMenuItemSelected(menuItem: MenuItem): Boolean {
        return when (menuItem.itemId) {
            // Llama a updateNoteInDb cuando se presiona el botón de guardar
            R.id.saveMenu -> {
                updateNoteInDb()
                true
            }
            R.id.deleteMenu -> {
                deleteNote()
                true
            }
            else -> false
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
