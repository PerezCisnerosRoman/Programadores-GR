package com.example.programagr

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import com.google.android.material.bottomnavigation.BottomNavigationView
import com.example.programagr.R // Asegúrate de que este import es correcto

// --- IMPORTA LOS OTROS FRAGMENTOS QUE VAS A MOSTRAR ---
// (ChatFragment, BuscadorFragment, etc.)
// Si HomeFragment está en un paquete diferente, ajusta los imports.

// HomeFragment se encarga de gestionar su propia vista y la navegación interna
class HomeFragment : Fragment() {

    // Declara la vista de la barra de navegación
    private lateinit var bottomNavigationView: BottomNavigationView

    /**
     * Este método CREA la vista del fragmento desde el archivo XML.
     * Es el primer paso.
     */
    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Infla el layout que contiene la BottomNavigationView y el FrameLayout
        // Asegúrate de que 'fragment_home.xml' existe y tiene esos componentes.
        return inflater.inflate(R.layout.fragment_home, container, false)
    }

    /**
     * Este método se llama JUSTO DESPUÉS de que la vista ha sido creada.
     * Aquí es donde debes configurar los listeners y encontrar las vistas.
     */
    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        // 1. INICIALIZA las vistas que están DENTRO del layout de este fragmento.
        // Se usa 'view.findViewById' porque estamos buscando dentro de la vista del fragmento.
        bottomNavigationView = view.findViewById(R.id.bottom_navigation)

        // --- INICIO DE LA LÓGICA DEL MENÚ ---

        // 2. Muestra un fragmento "hijo" por defecto al iniciar.
        if (savedInstanceState == null) {
            // Reemplaza el contenido del FrameLayout con el primer fragmento (ej. Chat)
            replaceFragment(MenuFragment())
            // Marcar el ítem del menú como seleccionado
            bottomNavigationView.selectedItemId = R.id.bottom_chat
        }

        // 3. Configura el listener para reaccionar a los clics del usuario.
        bottomNavigationView.setOnItemSelectedListener { menuItem ->
            when (menuItem.itemId) {
                // Cada 'id' debe coincidir con los del archivo menu.xml
                R.id.bottom_chat -> {
                    replaceFragment(ChatFragment())
                    true
                }
                R.id.bottom_buscador -> {
                    replaceFragment(BuscadorFragment()) // Corregido el nombre
                    true
                }
                R.id.bottom_menu -> {
                    replaceFragment(MenuFragment()) // Corregido el nombre
                    true
                }
                R.id.bottom_notas -> {
                    replaceFragment(NotasFragment())
                    true
                }
                R.id.bottom_perfil -> {
                    replaceFragment(PerfilFragment()) // Corregido el error de tipeo
                    true
                }
                // 'else' por si algo falla.
                else -> false
            }
        }
    }

    /**
     * Función auxiliar para cambiar el fragmento HIJO.
     * Es crucial usar 'childFragmentManager' aquí.
     */
    private fun replaceFragment(fragment: Fragment) {
        // childFragmentManager gestiona los fragmentos DENTRO de este fragmento (HomeFragment).
        // supportFragmentManager gestiona los fragmentos de la Actividad.
        val fragmentManager = childFragmentManager
        val fragmentTransaction = fragmentManager.beginTransaction()
        // 'R.id.frame_container_home' debe ser el ID del FrameLayout en fragment_home.xml
        fragmentTransaction.replace(R.id.frame_container_home, fragment)
        fragmentTransaction.commit()
    }
}

