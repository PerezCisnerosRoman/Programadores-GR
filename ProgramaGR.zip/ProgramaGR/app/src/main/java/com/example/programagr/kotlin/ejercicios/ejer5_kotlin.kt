package com.example.programagr.kotlin.ejercicios

class ejer5_kotlin {
}