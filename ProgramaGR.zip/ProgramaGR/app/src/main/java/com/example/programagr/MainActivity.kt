package com.example.programagr

import android.os.Bundle
import android.view.MenuItem
import android.view.View
import android.widget.ImageButton
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.GravityCompat
import androidx.drawerlayout.widget.DrawerLayout
import com.google.android.material.navigation.NavigationView

class MainActivity : AppCompatActivity(), NavigationView.OnNavigationItemSelectedListener {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        // Declarar variables
        val drawerLayout = findViewById<DrawerLayout>(R.id.drawerLayout)
        val buttonDrawer = findViewById<ImageButton>(R.id.buttonDrawer)
        val navigationView = findViewById<NavigationView>(R.id.navigationView)


        // Función del botón: abrir el Drawer
        buttonDrawer.setOnClickListener {
            drawerLayout.open()
        }

        val headerView: View = navigationView.getHeaderView(0)
        val useImage= headerView.findViewById<ImageView>(R.id.userImage)
        val textUsername= headerView.findViewById<TextView>(R.id.textUsername)

        useImage.setOnClickListener {
            Toast.makeText(this, textUsername.text, Toast.LENGTH_SHORT).show()
        }


        // Listener del menú lateral
        navigationView.setNavigationItemSelectedListener(this)
    }

    // Manejo de los ítems del menú
    override fun onNavigationItemSelected(item: MenuItem): Boolean {
        when (item.itemId) {
            R.id.navMenu -> {
                Toast.makeText(this,"Menu Clicked", Toast.LENGTH_SHORT).show()
            }
            R.id.navLeccion -> {
                Toast.makeText(this,"Leccion Clicked", Toast.LENGTH_SHORT).show()
            }
            R.id.navEjercicios -> {
                Toast.makeText(this,"Ejercicios Clicked", Toast.LENGTH_SHORT).show()
            }
            R.id.navProyectos -> {
                Toast.makeText(this,"Proyectos Clicked", Toast.LENGTH_SHORT).show()
            }
            R.id.navRetos -> {
                Toast.makeText(this,"Retos Clicked", Toast.LENGTH_SHORT).show()
            }
            R.id.navNoticias -> {
                Toast.makeText(this,"Noticias Clicked", Toast.LENGTH_SHORT).show()
            }
            R.id.navFavoritos -> {
                Toast.makeText(this,"Favoritos Clicked", Toast.LENGTH_SHORT).show()
            }
            R.id.navConfiguracion -> {
                Toast.makeText(this,"Configuracion Clicked", Toast.LENGTH_SHORT).show()
            }
            R.id.navAyuda -> {
                Toast.makeText(this,"Ayuda Clicked", Toast.LENGTH_SHORT).show()
            }
            R.id.navAcercade -> {
                Toast.makeText(this,"Acercade Clicked", Toast.LENGTH_SHORT).show()
            }
        }

        // Cierra el menú lateral después de la selección
        val drawerLayout = findViewById<DrawerLayout>(R.id.drawerLayout)
        drawerLayout.close()

        return true
    }
}
