package com.example.programagr

import android.os.Bundle
import android.view.MenuItem
import android.view.View
import android.widget.ImageButton
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import androidx.activity.OnBackPressedCallback
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.GravityCompat
import androidx.drawerlayout.widget.DrawerLayout
import androidx.fragment.app.Fragment
import androidx.fragment.app.commit
import com.example.programagr.ejercicio.ejer1_home
import com.google.android.material.navigation.NavigationView

// ESTE ES TU CÓDIGO ORIGINAL CON LA CORRECCIÓN
class MainActivity : AppCompatActivity(), NavigationView.OnNavigationItemSelectedListener {

    private lateinit var drawerLayout: DrawerLayout
    private lateinit var navigationView: NavigationView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        // ==========================================================
        // ===== ¡AQUÍ ESTÁ LA ÚNICA CORRECCIÓN QUE IMPORTA! =====
        val toolbar: androidx.appcompat.widget.Toolbar = findViewById(R.id.toolbar)
        setSupportActionBar(toolbar)
        // ==========================================================
// ===== AÑADE ESTA LÍNEA PARA OCULTAR EL TÍTULO FEO =====
        supportActionBar?.setDisplayShowTitleEnabled(false)
// ==
        // TU CÓDIGO ORIGINAL CONTINÚA AQUÍ, INTACTO.
        val buttonDrawer = findViewById<ImageButton>(R.id.buttonDrawer)

        // 1. Inicializar vistas
        drawerLayout = findViewById(R.id.drawerLayout)
        navigationView = findViewById(R.id.navigationView)

        // 2. Listener del botón para abrir el menú
        buttonDrawer.setOnClickListener {
            drawerLayout.open()
        }

        // 3. Listener para los ítems del menú
        navigationView.setNavigationItemSelectedListener(this)

        // 4. Lógica del Header View
        val headerView: View = navigationView.getHeaderView(0)
        val useImage = headerView.findViewById<ImageView>(R.id.userImage)
        val textUsername = headerView.findViewById<TextView>(R.id.textUsername)

        useImage.setOnClickListener {
            Toast.makeText(this, "Has hecho clic en la imagen de: ${textUsername.text}", Toast.LENGTH_SHORT).show()
        }

        // 5. Cargar el fragmento inicial (si es la primera vez que se abre la app)
        if (savedInstanceState == null) {
            openFragment(HomeFragment()) // Carga el fragmento de inicio
            navigationView.setCheckedItem(R.id.navMenu) // Marca la primera opción como seleccionada
        }

        // 6. Manejar el botón "atrás"
        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                if (drawerLayout.isDrawerOpen(GravityCompat.START)) {
                    drawerLayout.closeDrawer(GravityCompat.START)
                } else {
                    isEnabled = false
                    onBackPressedDispatcher.onBackPressed() // Comportamiento por defecto (cerrar fragment/app)
                    isEnabled = true
                }
            }
        })
    }

    // 7. Tu método onNavigationItemSelected original, intacto.
    override fun onNavigationItemSelected(item: MenuItem): Boolean {
        val fragmentToShow: Fragment = when (item.itemId) {
            R.id.navMenu -> {
                Toast.makeText(this, "Menu Clicked", Toast.LENGTH_SHORT).show()
                HomeFragment()
            }
            R.id.navLeccion -> {
                Toast.makeText(this, "Lección Clicked", Toast.LENGTH_SHORT).show()
                LeccionFragment()
            }
            R.id.navEjercicios -> {
                Toast.makeText(this, "Ejercicios Clicked", Toast.LENGTH_SHORT).show()
                ejer1_home()
            }
            R.id.navNotas -> {
                Toast.makeText(this, "Notas Clicked", Toast.LENGTH_SHORT).show()
                NotasFragment()
            }
            R.id.navNoticias -> {
                Toast.makeText(this, "Noticias Clicked", Toast.LENGTH_SHORT).show()
                NoticiasFragment()
            }
            R.id.navFavoritos -> {
                Toast.makeText(this, "Favoritos Clicked", Toast.LENGTH_SHORT).show()
                FavoritosFragment()
            }
            R.id.navConfiguracion -> {
                Toast.makeText(this, "Configuración Clicked", Toast.LENGTH_SHORT).show()
                ConfiguracionFragment()
            }
            R.id.navAyuda -> {
                Toast.makeText(this, "Ayuda Clicked", Toast.LENGTH_SHORT).show()
                AyudaFragment()
            }
            R.id.navAcercade -> {
                Toast.makeText(this, "Acerca de Clicked", Toast.LENGTH_SHORT).show()
                AcercaDeFragment()
            }
            else -> {
                HomeFragment()
            }
        } as Fragment
        openFragment(fragmentToShow)
        drawerLayout.closeDrawer(GravityCompat.START)
        return true
    }

    // 8. Tu función openFragment original, intacta.
    private fun openFragment(fragment: Fragment) {
        supportFragmentManager.commit {
            replace(R.id.content_frame, fragment)
            setReorderingAllowed(true)
        }
    }
}

