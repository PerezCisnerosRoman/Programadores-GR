// Top-level build file where you can add configuration options common to all sub-projects/modules.
buildscript {
    repositories {
        google()
    }

    dependencies {
        val navVersion = "2.7.5"
        classpath("androidx.navigation:navigation-safe-args-gradle-plugin:$navVersion")
    }
}

// En tu archivo build.gradle.kts (A NIVEL DE PROYECTO)

plugins {
    // Plugin de Android para la aplicación
    id("com.android.application") version "8.13.0" apply false

    // Plugin de Kotlin para Android (la versión debe coincidir con la de abajo)
    id("org.jetbrains.kotlin.android") version "1.9.22" apply false

    // Plugin KSP (el procesador de anotaciones)
    id("com.google.devtools.ksp") version "1.9.22-1.0.17" apply false

    // ¡¡AÑADE ESTA LÍNEA AQUÍ!!
    // Esto le dice a todo el proyecto dónde encontrar el plugin "kotlin-parcelize".
    id("org.jetbrains.kotlin.plugin.parcelize") version "1.9.22" apply false

}
