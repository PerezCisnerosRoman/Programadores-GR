package com.example.cosaesta.netbeans

import android.content.Intent
import android.os.Bundle
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.cosaesta.R
import com.example.cosaesta.kotlin.ejer1

class netbeanskt : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_main_netbeans)

        // FIX 1: If 'main' is red, ensure your XML root view has android:id="@+id/main"
        // If you can't find the ID, try finding the root view directly via window.decorView
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        val recycler = findViewById<RecyclerView>(R.id.recyclerEjercicios)

        // FIX 2: Corrected list using a single data class
        val netbejericios = listOf(
            netbejericio("Ejercicio 1", "Escribe un programa que muestre tu nombre y edad"),
            netbejericio("Ejercicio 2", "Crea variables de tipo String, Int, Double, Boolean"),
            netbejericio("Ejercicio 3", "Pide la edad del usuario y muestra si es mayor de edad"),
            netbejericio("Ejercicio 4", "Imprimir los números del 1 al 10"),
            netbejericio("Ejercicio 5", "Crea una lista de 5 frutas y muéstralas"),
            netbejericio("Ejercicio 6", "Crea una función que reciba 2 números y regrese su multiplicación")
        )


        recycler.layoutManager = GridLayoutManager(this, 2)

// Pass the lambda function to handle the click
        recycler.adapter = netbAdaptador(netbejericios) { netbejericiosClicked ->
            // Create the Intent to switch activities
            val intent = Intent(this, ejer1::class.java)

            // Optional: Pass data to the new activity
            intent.putExtra("TITULO", netbejericiosClicked.titulo)
            intent.putExtra("DESCRIPCION", netbejericiosClicked.descripcion)

            startActivity(intent)
        }
    }
}

// New Data Class
data class netbejericio(val titulo: String, val descripcion: String)
