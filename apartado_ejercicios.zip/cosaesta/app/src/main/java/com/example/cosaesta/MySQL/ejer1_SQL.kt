package com.example.cosaesta.MySQL

import android.os.Bundle
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import com.example.cosaesta.R

class ejer1_SQL : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.ejer1_kotlin)

        // 1. Find the views we created in the XML
        val tvTitle = findViewById<TextView>(R.id.tvDetailTitle)
        val tvDesc = findViewById<TextView>(R.id.tvDetailDesc)

        // 2. Get the data from the Intent
        // The keys "TITULO" and "DESCRIPCION" must match exactly what you wrote in MainActivity
        val tituloRecibido = intent.getStringExtra("TITULO")
        val descripcionRecibida = intent.getStringExtra("DESCRIPCION")


        // 3. Set the text to the views
        tvTitle.text = tituloRecibido
        tvDesc.text = descripcionRecibida
    }
}