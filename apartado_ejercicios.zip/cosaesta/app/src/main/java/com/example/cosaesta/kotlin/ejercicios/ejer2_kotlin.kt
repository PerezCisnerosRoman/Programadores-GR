package com.example.cosaesta.kotlin.ejercicios

class ejer2_kotlin {
}