package com.example.cosaesta.kotlin

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.example.cosaesta.R

class Adaptador(private val lista: List<Ejercicio>,
                private val onClick: (Ejercicio) -> Unit)
    :
    RecyclerView.Adapter<Adaptador.ViewHolder>() {



    class ViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        val titulo: TextView = view.findViewById(R.id.listName)

        val descripcion: TextView = view.findViewById(R.id.listDesc)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.boton, parent, false)
        return ViewHolder(view)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val item = lista[position]

        // 3. Bind the data to both text views
        holder.titulo.text = item.titulo
        holder.descripcion.text = item.descripcion
        holder.itemView.setOnClickListener {
            onClick(item)

        }
    }

    override fun getItemCount(): Int = lista.size
}
