package com.example.cosaesta.MySQL

import android.content.Intent
import android.os.Bundle
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.cosaesta.R

class MainActivity_SQL : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_main_sql)

        // FIX 1: If 'main' is red, ensure your XML root view has android:id="@+id/main"
        // If you can't find the ID, try finding the root view directly via window.decorView
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        val recycler = findViewById<RecyclerView>(R.id.recyclerEjercicios)

        // FIX 2: Corrected list using a single data class
        val ejercicios_sql = listOf(
            Ejercicio_sql("Ejercicio 1", "Escribe un programa que muestre tu nombre y edad"),
            Ejercicio_sql("Ejercicio 2", "Crea variables de tipo String, Int, Double, Boolean"),
            Ejercicio_sql("Ejercicio 3", "Pide la edad del usuario y muestra si es mayor de edad"),
            Ejercicio_sql("Ejercicio 4", "Imprimir los números del 1 al 10"),
            Ejercicio_sql("Ejercicio 5", "Crea una lista de 5 frutas y muéstralas"),
            Ejercicio_sql(
                "Ejercicio 6",
                "Crea una función que reciba 2 números y regrese su multiplicación"
            )
        )


        recycler.layoutManager = GridLayoutManager(this, 2)

// Pass the lambda function to handle the click
        recycler.adapter = Adaptador_SQL(ejercicios_sql) { ejercicio_sqlClicked ->
            // Create the Intent to switch activities
            val intent = Intent(this, ejer1_SQL::class.java)

            // Optional: Pass data to the new activity
            intent.putExtra("TITULO", ejercicio_sqlClicked.titulo)
            intent.putExtra("DESCRIPCION", ejercicio_sqlClicked.descripcion)

            startActivity(intent)
        }
    }
}

// New Data Class
data class Ejercicio_sql(val titulo: String, val descripcion: String)
