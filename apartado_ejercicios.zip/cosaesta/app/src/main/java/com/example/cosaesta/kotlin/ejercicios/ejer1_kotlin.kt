package com.example.cosaesta.kotlin.ejercicios

class ejer1_kotlin {
}