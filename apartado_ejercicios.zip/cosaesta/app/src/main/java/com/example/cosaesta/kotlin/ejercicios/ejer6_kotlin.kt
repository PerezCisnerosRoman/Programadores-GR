package com.example.cosaesta.kotlin.ejercicios

class ejer6_kotlin {
}