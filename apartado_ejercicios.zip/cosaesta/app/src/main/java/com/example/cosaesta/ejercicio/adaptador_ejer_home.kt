package com.example.cosaesta.ejercicio

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.example.cosaesta.R


class EjercicioAdapter
    (private val lista: List<Ejercicio_home>,
     private val onClick: (Ejercicio_home) -> Unit)
    :
    RecyclerView.Adapter<EjercicioAdapter.ViewHolder>() {



    class ViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        val titulo: TextView = view.findViewById(R.id.listName)
        val imagen: ImageView = view.findViewById(R.id.imagen)
        val descripcion: TextView = view.findViewById(R.id.listDesc)

    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.boton, parent, false)
        return ViewHolder(view)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val item = lista[position]

        // 3. Bind the data to both text views
        holder.titulo.text = item.titulo
        holder.descripcion.text = item.descripcion

        // THIS IS THE NEW LINE FOR THE IMAGE
        holder.imagen.setImageResource(item.imagen)

        holder.itemView.setOnClickListener {
            onClick(item)
        }
    }

    override fun getItemCount(): Int = lista.size
}
