package layout.MySQL

import android.content.Intent
import android.os.Bundle
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.cosaesta.ejercicio.Ejercicio
import com.example.cosaesta.R

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_main)

        // FIX 1: If 'main' is red, ensure your XML root view has android:id="@+id/main"
        // If you can't find the ID, try finding the root view directly via window.decorView
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        val recycler = findViewById<RecyclerView>(R.id.recyclerEjercicios)

        // FIX 2: Corrected list using a single data class
        val ejercicios = listOf(
            Ejercicio("Ejercicio 1", "Escribe un programa que muestre tu nombre y edad"),
            Ejercicio("Ejercicio 2", "Crea variables de tipo String, Int, Double, Boolean"),
            Ejercicio("Ejercicio 3", "Pide la edad del usuario y muestra si es mayor de edad"),
            Ejercicio("Ejercicio 4", "Imprimir los números del 1 al 10"),
            Ejercicio("Ejercicio 5", "Crea una lista de 5 frutas y muéstralas"),
            Ejercicio(
                "Ejercicio 6",
                "Crea una función que reciba 2 números y regrese su multiplicación"
            )
        )


        recycler.layoutManager = GridLayoutManager(this, 2)

// Pass the lambda function to handle the click
        recycler.adapter = Adaptador_SQL(ejercicios) { ejercicioClicked ->
            // Create the Intent to switch activities
            val intent = Intent(this, ejer1::class.java)

            // Optional: Pass data to the new activity
            intent.putExtra("TITULO", ejercicioClicked.titulo)
            intent.putExtra("DESCRIPCION", ejercicioClicked.descripcion)

            startActivity(intent)
        }
    }
}

// New Data Class
data class Ejercicio_home(val titulo: String, val descripcion: String)
